"""Relevant prompts for constructing indexes."""
